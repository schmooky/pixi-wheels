pixi-wheels sample textures
===========================

Generated art, MIT licensed like the library. Use them anywhere, change
them, ship them. Rebuilt by tools/doc-figures/build_figures.py in the
pixi-wheels repo.

Every file is transparent PNG, drawn to the requirements the recipes state:

  https://pixi-wheels.schmooky.dev/recipes/disc-art/
  https://pixi-wheels.schmooky.dev/recipes/tongue/

Discs are square with transparent corners and are centred on the image
centre; angles start at three o'clock and grow clockwise. Plates are
authored upright with their outward edge at the top and are anchored dead
centre. Tongues have their tip on the top edge (artDirection: 'up') and
their pin at { x: 0.5, y: 0.85 }, so any one can replace any other.

Files
-----

  disc-art/bezel-steel.png            1152 x 1152   brushed-steel bezel with 32 smaller bulbs
  disc-art/bezel.png                  1152 x 1152   gold bezel with 24 bulbs
  disc-art/bulb-off.png                 64 x 64     the same bulb, dark
  disc-art/bulb-on.png                  64 x 64     a lit rim bulb
  disc-art/face-24.png                1024 x 1024   24 fine wedges for a ratchet-heavy wheel
  disc-art/face-8.png                 1024 x 1024   8 wedges in a softer four-colour palette
  disc-art/face.png                   1024 x 1024   12 crimson and navy wedges, gold dividers
  disc-art/glow.png                    256 x 256    soft radial glow, additive, for the winning wedge
  disc-art/hub-plain.png               320 x 320    a plain steel hub cap
  disc-art/hub.png                     320 x 320    the default hub cap
  disc-art/peg.png                      48 x 48     a single peg stud, for skins that draw their own
  disc-art/plate-blue.png              256 x 320    blue plate, same silhouette
  disc-art/plate-dim.png               256 x 320    the dimmed loser state
  disc-art/plate-gold.png              256 x 320    gold plate for the top prize
  disc-art/plate-green.png             256 x 320    green plate, same silhouette
  disc-art/plate-win.png               256 x 320    the lit winner state
  disc-art/plate.png                   256 x 320    the default crimson plate
  tongue/tongue-arrow.png              160 x 260    a chunky cartoon arrow with a heavy outline
  tongue/tongue-needle.png             160 x 260    a steel needle: high stiffness, high damping, small maxAngle
  tongue/tongue-rubber.png             160 x 260    a soft red flapper: pair with low stiffness and low damping
  tongue/tongue.png                    160 x 260    the default gold tongue, tip up, pin at 0.5 / 0.85
